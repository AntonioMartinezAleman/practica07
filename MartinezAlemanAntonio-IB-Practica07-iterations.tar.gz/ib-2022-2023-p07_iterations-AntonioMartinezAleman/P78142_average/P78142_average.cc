  
/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  * @author Antonio Martinez Aleman alu0101548029@ull.edu.es
  * @date 15 Nov 2022
  * @brief Write a program that reads a sequence of numbers and prints their
  * average.
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P78142
  */
 
#include <iostream>
#include <cmath>
#include <iomanip>

int main() {
    int num{0},power{0};
    while (std::cin >> num >> power) {
        std::cout << std::fixed << std::setprecision(0) << pow(num,power) << std::endl;
    }
    return 0;
} 
