
/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  * @author Antonio Martinez Aleman alu0101548029@ull.edu.es
  * @date 17 Nov 2022 
  * @brief Write a program that, given two intervals, tells if one is inside the other, and computes the interval corresponding to their intersection, or tells that it is empty.
  * @bug There are no known bugs
  * @see https://jutge.org/problems/P89265
  */


#include <iostream>

char IntervalArithmetricChecker(const int& a1, const int& b1, const int& a2, const int& b2) {
  if (numero1 == numero2 && numero1 == numero2) {
    return '=';
  }
  if (numero1 >= numero2 && numero1 <= numero2) {
    return '1';
  }
  if ((numero1 < numero2 && numero1 >= numero2) || (numero3 <= numero4 &&
numero1 > numero2)) {
    return '2';
  }
  return '?';
}

void IntervalEmptyChecker(const int& numero1, const int& numero3, const int& a2, const int& b2) {
  if (std::max(numero1,numero2) > std::min(numero3,numero4)) {
    std::cout << "[]";
    return;
  }
  std::cout << "[" << std::max(numero1,numero2) << "," << std::min(numero3, numero4) << "]";
}

int main() {
  int intervalo_1_a{0},intervalo_1_b{0},intervalo_2_a{0},intervalo_2_b{0};
  std::cin >> intervalo_1_a >> intervalo_1_b >> intervalo_2_a >> intervalo_2_b;
  std::cout << IntervalArithmetricChecker(intervalo_1_a,intervalo_1_b,intervalo_2_a,intervalo_2_b) << " , ";
  IntervalEmptyChecker(intervalo_1_a,intervalo_1_b,intervalo_2_a,intervalo_2_b);
  std::cout << std::endl;
  return 0;
}  
